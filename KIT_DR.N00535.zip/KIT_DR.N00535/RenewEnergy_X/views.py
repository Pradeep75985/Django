from django.shortcuts import render
import matplotlib.pyplot as plt
import numpy as np

def base(request):
    return render(request, 'base.html')

def register(request):
    return render(request, 'register.html')

def login(request):
    return render(request, 'login.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def home(request):
    return render(request, 'home.html')

def monitoring(request):
    return render(request, 'monitoring.html')

def optimization(request):
    return render(request, 'optimization.html')

def dashboard(request):
    # Generate sample data (replace this with your actual data)
    x = np.linspace(0, 10, 100)
    y = np.sin(x)

    # Create a line plot
    plt.figure(figsize=(8, 6))
    plt.plot(x, y)
    plt.xlabel('X-axis')
    plt.ylabel('Y-axis')
    plt.title('Sample Line Plot')
    plt.grid(True)

    # Save the plot as an image file
    plot_path = 'static/images/line_plot.png'
    plt.savefig(plot_path)

    # Pass the path of the saved plot to the template
    context = {'plot_path': plot_path}
    return render(request, 'dashboard.html', context)

def error(request, error_message):
    return render(request, 'error.html', {'error_message': error_message})
