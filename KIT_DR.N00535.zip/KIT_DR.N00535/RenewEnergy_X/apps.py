from django.apps import AppConfig


class RenewenergyXConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'RenewEnergy_X'
